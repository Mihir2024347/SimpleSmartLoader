#define _GNU_SOURCE

#include "loader.h"

#include <signal.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>

#define PAGE_SIZE 4096

Elf32_Ehdr *ehdr;
Elf32_Phdr *phdr;
int fd = -1;

typedef struct
{
    uintptr_t address;
} PageRecord;

static unsigned char *elf_data = NULL;
static size_t elf_size = 0;

static PageRecord *allocated_pages = NULL;
static size_t allocated_count = 0;
static size_t allocated_capacity = 0;

static unsigned long page_fault_count = 0;
static unsigned long page_allocation_count = 0;
static unsigned long long fragmentation_bytes = 0;

static struct sigaction old_segv_action;
static int handler_installed = 0;

static int page_already_allocated(uintptr_t address)
{
    size_t i;

    for (i = 0; i < allocated_count; i++)
    {
        if (allocated_pages[i].address == address)
        {
            return 1;
        }
    }

    return 0;
}

static int address_in_load_segment(uintptr_t address)
{
    int i;

    for (i = 0; i < ehdr->e_phnum; i++)
    {
        uint64_t start;
        uint64_t end;

        if (phdr[i].p_type != PT_LOAD)
        {
            continue;
        }

        start = phdr[i].p_vaddr;
        end = start + phdr[i].p_memsz;

        if ((uint64_t)address >= start &&
            (uint64_t)address < end)
        {
            return 1;
        }
    }

    return 0;
}

static void load_one_page(uintptr_t page_address)
{
    unsigned char covered[PAGE_SIZE] = {0};
    int protection = 0;
    size_t valid_bytes = 0;
    int i;
    void *mapped_page;

    /*
     * First pass: find all segments overlapping this page.
     */
    for (i = 0; i < ehdr->e_phnum; i++)
    {
        uint64_t seg_start;
        uint64_t seg_end;
        uint64_t page_end;
        uint64_t overlap_start;
        uint64_t overlap_end;
        uint64_t j;

        if (phdr[i].p_type != PT_LOAD)
            continue;

        seg_start = phdr[i].p_vaddr;
        seg_end = seg_start + phdr[i].p_memsz;
        page_end = (uint64_t)page_address + PAGE_SIZE;

        if (seg_start >= page_end || seg_end <= page_address)
            continue;

        if (phdr[i].p_flags & PF_R)
            protection |= PROT_READ;

        if (phdr[i].p_flags & PF_W)
            protection |= PROT_WRITE;

        if (phdr[i].p_flags & PF_X)
            protection |= PROT_EXEC;

        overlap_start = seg_start > page_address ?
                        seg_start : page_address;

        overlap_end = seg_end < page_end ?
                      seg_end : page_end;

        for (j = overlap_start; j < overlap_end; j++)
            covered[j - page_address] = 1;
    }

    if (protection == 0)
        _exit(1);

    for (i = 0; i < PAGE_SIZE; i++)
    {
        if (covered[i])
            valid_bytes++;
    }

    /*
     * Allocate the page BEFORE copying anything into it.
     */
    mapped_page = mmap((void *)page_address,
                       PAGE_SIZE,
                       PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
                       -1, 0);

    if (mapped_page == MAP_FAILED)
        _exit(1);

    /*
     * Second pass: copy file-backed bytes.
     * BSS bytes remain zero because mmap initializes memory to zero.
     */
    for (i = 0; i < ehdr->e_phnum; i++)
    {
        uint64_t seg_start;
        uint64_t file_end;
        uint64_t page_end;
        uint64_t copy_start;
        uint64_t copy_end;
        uint64_t source_offset;

        if (phdr[i].p_type != PT_LOAD)
            continue;

        seg_start = phdr[i].p_vaddr;
        file_end = seg_start + phdr[i].p_filesz;
        page_end = (uint64_t)page_address + PAGE_SIZE;

        copy_start = seg_start > page_address ?
                     seg_start : page_address;

        copy_end = file_end < page_end ?
                   file_end : page_end;

        if (copy_start >= copy_end)
            continue;

        source_offset =
            phdr[i].p_offset + (copy_start - seg_start);

        if (source_offset + copy_end - copy_start > elf_size)
            _exit(1);

        memcpy((char *)mapped_page + (copy_start - page_address),
               elf_data + source_offset,
               copy_end - copy_start);
    }

    if (mprotect(mapped_page, PAGE_SIZE, protection) != 0)
        _exit(1);

    if (allocated_count >= allocated_capacity)
        _exit(1);

    allocated_pages[allocated_count].address = page_address;
    allocated_count++;

    page_allocation_count++;
    fragmentation_bytes += PAGE_SIZE - valid_bytes;
}

static void segmentation_fault_handler(int signal_number,
                                       siginfo_t *information,
                                       void *context)
{
    uintptr_t fault_address;
    uintptr_t page_address;

    (void)context;

    if (signal_number != SIGSEGV || information == NULL)
    {
        _exit(128 + SIGSEGV);
    }

    fault_address = (uintptr_t)information->si_addr;

    if (!address_in_load_segment(fault_address))
    {
        _exit(128 + SIGSEGV);
    }

    page_address = fault_address & ~((uintptr_t)PAGE_SIZE - 1);

    /*
     * A second fault on an already allocated page is
     * an invalid access, not a missing page.
     */
    if (page_already_allocated(page_address))
    {
        _exit(128 + SIGSEGV);
    }

    page_fault_count++;

    load_one_page(page_address);
}

static void read_elf_file(const char *filename)
{
    struct stat file_status;
    size_t bytes_read = 0;

    fd = open(filename, O_RDONLY);

    if (fd < 0)
    {
        perror("Unable to open ELF file");
        exit(EXIT_FAILURE);
    }

    if (fstat(fd, &file_status) != 0)
    {
        perror("fstat");
        exit(EXIT_FAILURE);
    }

    if (file_status.st_size < (off_t)sizeof(Elf32_Ehdr))
    {
        fprintf(stderr, "Invalid ELF file size\n");
        exit(EXIT_FAILURE);
    }

    elf_size = (size_t)file_status.st_size;

    elf_data = malloc(elf_size);

    if (elf_data == NULL)
    {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    while (bytes_read < elf_size)
    {
        ssize_t result = read(fd,
                              elf_data + bytes_read,
                              elf_size - bytes_read);

        if (result <= 0)
        {
            perror("Unable to read ELF file");
            exit(EXIT_FAILURE);
        }

        bytes_read += (size_t)result;
    }

    ehdr = (Elf32_Ehdr *)elf_data;

    if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG) != 0)
    {
        fprintf(stderr, "Invalid ELF magic\n");
        exit(EXIT_FAILURE);
    }

    if (ehdr->e_ident[EI_CLASS] != ELFCLASS32)
    {
        fprintf(stderr, "Only ELF 32-bit executables are supported\n");
        exit(EXIT_FAILURE);
    }

    if (ehdr->e_ident[EI_DATA] != ELFDATA2LSB ||
        ehdr->e_machine != EM_386 ||
        ehdr->e_type != ET_EXEC)
    {
        fprintf(stderr, "Unsupported ELF executable format\n");
        exit(EXIT_FAILURE);
    }

    if (ehdr->e_phentsize != sizeof(Elf32_Phdr))
    {
        fprintf(stderr, "Invalid program header size\n");
        exit(EXIT_FAILURE);
    }

    if ((uint64_t)ehdr->e_phoff +
        (uint64_t)ehdr->e_phnum * sizeof(Elf32_Phdr) > elf_size)
    {
        fprintf(stderr, "Invalid program header table\n");
        exit(EXIT_FAILURE);
    }

    phdr = (Elf32_Phdr *)(elf_data + ehdr->e_phoff);
}

static void prepare_page_records(void)
{
    size_t capacity = 0;
    int i;

    for (i = 0; i < ehdr->e_phnum; i++)
    {
        uint64_t start;
        uint64_t end;
        uint64_t first_page;
        uint64_t last_page;

        if (phdr[i].p_type != PT_LOAD)
        {
            continue;
        }

        if (phdr[i].p_memsz < phdr[i].p_filesz)
        {
            fprintf(stderr, "Invalid PT_LOAD segment sizes\n");
            exit(EXIT_FAILURE);
        }

        if ((uint64_t)phdr[i].p_offset + phdr[i].p_filesz > elf_size)
        {
            fprintf(stderr, "Segment extends beyond ELF file\n");
            exit(EXIT_FAILURE);
        }

        start = phdr[i].p_vaddr;
        end = start + phdr[i].p_memsz;

        if (end > 0x100000000ULL || end < start)
        {
            fprintf(stderr, "Invalid segment address range\n");
            exit(EXIT_FAILURE);
        }

        if (phdr[i].p_memsz == 0)
        {
            continue;
        }

        first_page = start & ~((uint64_t)PAGE_SIZE - 1);
        last_page = (end - 1) & ~((uint64_t)PAGE_SIZE - 1);

        capacity += (size_t)((last_page - first_page) /
                             PAGE_SIZE + 1);
    }

    if (capacity == 0)
    {
        fprintf(stderr, "No loadable ELF segments found\n");
        exit(EXIT_FAILURE);
    }

    allocated_pages = calloc(capacity, sizeof(PageRecord));

    if (allocated_pages == NULL)
    {
        perror("calloc");
        exit(EXIT_FAILURE);
    }

    allocated_capacity = capacity;
}

static void install_fault_handler(void)
{
    struct sigaction action;

    memset(&action, 0, sizeof(action));

    action.sa_sigaction = segmentation_fault_handler;
    action.sa_flags = SA_SIGINFO;

    sigemptyset(&action.sa_mask);

    if (sigaction(SIGSEGV, &action, &old_segv_action) != 0)
    {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    handler_installed = 1;
}

/*
 * Release memory and other cleanups.
 */
void loader_cleanup(void)
{
    size_t i;

    if (handler_installed)
    {
        sigaction(SIGSEGV, &old_segv_action, NULL);
        handler_installed = 0;
    }

    for (i = 0; i < allocated_count; i++)
    {
        munmap((void *)allocated_pages[i].address, PAGE_SIZE);
    }

    free(allocated_pages);
    allocated_pages = NULL;
    allocated_count = 0;
    allocated_capacity = 0;

    free(elf_data);
    elf_data = NULL;

    ehdr = NULL;
    phdr = NULL;
    elf_size = 0;

    if (fd >= 0)
    {
        close(fd);
        fd = -1;
    }
}

/*
 * Load and execute an ELF executable using demand paging.
 */
void load_and_run_elf(char **exe)
{
    int result;
    int entry_is_valid = 0;
    int i;

    if (exe == NULL || *exe == NULL)
    {
        fprintf(stderr, "Missing ELF executable path\n");
        return;
    }

    read_elf_file(*exe);

    for (i = 0; i < ehdr->e_phnum; i++)
    {
        uint64_t start;
        uint64_t end;

        if (phdr[i].p_type != PT_LOAD ||
            !(phdr[i].p_flags & PF_X))
        {
            continue;
        }

        start = phdr[i].p_vaddr;
        end = start + phdr[i].p_memsz;

        if (ehdr->e_entry >= start && ehdr->e_entry < end)
        {
            entry_is_valid = 1;
            break;
        }
    }

    if (!entry_is_valid)
    {
        fprintf(stderr, "ELF entry point is not in an executable segment\n");
        loader_cleanup();
        return;
    }

    prepare_page_records();

    page_fault_count = 0;
    page_allocation_count = 0;
    fragmentation_bytes = 0;

    install_fault_handler();

    printf("Starting SimpleSmartLoader...\n");
    printf("Entry point: 0x%08x\n", ehdr->e_entry);
    fflush(stdout);

    /*
     * No PT_LOAD segment has been mapped at this point.
     * The first access to the entry point triggers SIGSEGV.
     */
    {
        int (*entry_function)(void) =
            (int (*)(void))(uintptr_t)ehdr->e_entry;

        result = entry_function();
    }

    printf("User _start return value = %d\n", result);

    printf("\nSimpleSmartLoader Statistics\n");
    printf("Total page faults: %lu\n", page_fault_count);
    printf("Total page allocations: %lu\n", page_allocation_count);
    printf("Total internal fragmentation: %.3f KB\n",
           (double)fragmentation_bytes / 1024.0);

    if (handler_installed)
    {
        sigaction(SIGSEGV, &old_segv_action, NULL);
        handler_installed = 0;
    }
}
