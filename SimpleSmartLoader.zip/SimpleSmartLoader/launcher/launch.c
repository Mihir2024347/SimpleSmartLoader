#include <stdio.h>
#include <stdlib.h>
#include "loader.h"
int main(int argc, char **argv)
{
    if (argc != 2) {
        printf("Usage: %s <ELF executable>\n", argv[0]);
        return 1;
    }
    load_and_run_elf(&argv[1]);
    loader_cleanup();
    return 0;
}

